Workload splitting: 

    Antoine Roger (312065): 1/3
    Benoit Morawiec (312622): 1/3
    Baptiste Copros (312639): 1/3


The encountered difficulty was to know what to normalize and how to compute the lightening. 
Otherwise it was straight forward applying the formulaes. 